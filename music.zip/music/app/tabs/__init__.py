from .data_model import render_data_model_tab
from .predictions import render_prediction_tab
from .explore_data import render_explore_tab
from .report import render_report_tab